
                    //ENONCE DE L'EXERCICE

//on ceut realiser un algorithm qui permet de jouer contre l'ordinateur.l'ordi propose un nombre entier aleatoire grace a la fonction predefinie
//aleatoire(100) qui permet de generer un nombre aleatoire entier entre 0 et 100 different ceci a chaque execution
//l'ordinateur demande a l'utilisateur(ou le jouer) de deviner ce nombre entier compris entre 0 et 100.l'ordinateur propose 3 niveaux de difficulte:
//DIFFICILE avec 10 tentatives
// MOYEN avec 20 tentatives
//facile avec 30 tentatives
//si la tentative n'est pas correcte ,l'ordinateur affiche le <<le nombre est plus petip>> ou << le nombre est plus grand>> et demande une nouvelle 
//fois de saisir un autre nombre.l'algorithm s'arrete dans 2 cas a) si l'utilisateur trouve le nombre cache proposer par l'ordinateur et il affiche 
//"BRAVO" et retourne le nombre de tentative .b) si l'utilisateur depasse le nombre de tentative(selon les 3 niveaux de difficultes)l'ordinat affiche
//"GAME OVER " en plus de la solution (nombre cache proposer pa l'ordinateur)



#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

 main() {
 	
 	int a,n,t,dif,c=2; // dif : pour le niveau de difficulter
 	
 	printf("choisir la difficulter \n 1 difficile -2 Moyen -3 Difficile : ");
 	
 	scanf("%d" , &dif);
 	
 	if(dif==3)
 	t=29;
 	
 	else
 	
 	if(dif==2)
 	t=19;
 	else
 	t==9;
 	
 	srand(time(NULL));
 	a=rand() % 100;
 	
 	printf("essayer le deviner le nombre secret entre 1 et 100 -- Tentative 1-- : ");
 	scanf("%d" ,&n);
 	
 	while((a!=n)&&(t!=0))
 	{
 		if(n>a)
 		printf("Le nombre est plus petit \n");
 		
 		else
 		printf("Le nombre est plus grand \n");
 		t=t-1;
 		printf("essayer encore");
 		printf("--Tentative :%d --:" ,c);
 		scanf("%d" ,&n);
 		c++;
	 }
	 if(t==0)
	 {
	 	
	 	printf("***GAME OVER***GAME OVER***GAME OVER***\n");
	 	printf("--solution : %d --" , a);

	 }
	 else
	 printf("BRAVO... LE NOMBRE TENTETIVE = %d \n" ,c-1);
	
}

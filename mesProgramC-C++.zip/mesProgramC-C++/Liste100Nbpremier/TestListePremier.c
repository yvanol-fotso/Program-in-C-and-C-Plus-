#include <stdio.h>
#include <stdlib.h>

//PROGRAMME QUI VERIFIE SI LES  n NOMBRE ENTRER PAR L4UTILISATEUR SONT PREMIER

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int nombre=1,compteur=0;
	 int i, r ,n= 100;
	 
	  while(compteur < n){ // les n premiers
	  
	   r=0; //pour compter le nombres d diviseur
	   nombre ++;
	   for(i=1; i<= nombre ;i++){
	   	
	   	  if((nombre%i)==0)
	   	    
	   	    r++;
	   	
	   }
	      if(r==2) //ie le nombre premierv se divise sur 1 et lui meme
	      {
	      	
	      	printf("%d  ",nombre);
	      	
	      	compteur++; // on incremente le compteur
		  }
	  		
	  	
	  }
	
	
	return 0;
}

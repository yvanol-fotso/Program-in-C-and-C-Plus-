#include <stdio.h>
#include <stdlib.h>

void Triselection(int tab[],int n){
	
	int i=0, min , j ,tmp ;
	
	for(i=0; i<n-1;i++){
		
		min=i;
		
		for(j=i+1; j<n ; j++){
			
			if(tab[j]<tab[min])
			
			  min=j;
			
		}
		
		 tmp=tab[i];
		 tab[i]=tab[min];
		 tab[min]=tmp;
		
			
	}
	
	return;
}


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int n,i ;
    
    int TAB [100];
    
   //  int *TAB=(int*)malloc(sizeof(int)*n);
    
    printf ("\n entrer la taillle de votre tableau:");
    
        scanf("%d",&n);

    printf("\n entre les elements du tableau ");

    for(i=0;i<n;i++){
    	
    	 scanf("%d",&TAB[i]);
	
   	    // printf("elements %d\n",i);	
   	     
    }
    
    printf("\n le tableau avant le tri est: ");
    
    for(i=0;i<n;i++){
    	
	    printf("%d  ",TAB[i]);
    }
    
	 printf("\n\n");
	
    Triselection(TAB,n);
    
     printf("\n le tableau apres le tri est: ");
    
    for(i=0;i<n;i++){
	
         printf("%d  ",TAB[i]);
         
    }
    
    printf("\n");
    
	
	return 0;
}

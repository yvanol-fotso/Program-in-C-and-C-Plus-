#include <stdio.h>
void TriBulle(int *tab,int n)
{
	int i;
    int permut = 1;
    int j = 0;
    while(permut)
    {
        permut = 0;
        j++;
        for(i = 0;i <= n-j;i++)
        {
            if(tab[i] > tab[i+1])
            {
                int tmp = tab[i];
                tab[i] = tab[i+1];
                tab[i+1] = tmp;
                permut = 1;
            }
        }
    }
}

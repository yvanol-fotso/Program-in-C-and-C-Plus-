#include <stdio.h>
void TriSelection(int *tab, int n){
    int i,j,tmp,index;

    for(i=0;i<n-1;i++){
        index = i;
        for(j=i+1;j<n;j++){
            if(tab[index]>tab[j])
            index = j;
        }
        if(index != i){
            tmp = tab[i];
            tab[i] = tab[index];
            tab[index] = tmp;
        }
    }
}
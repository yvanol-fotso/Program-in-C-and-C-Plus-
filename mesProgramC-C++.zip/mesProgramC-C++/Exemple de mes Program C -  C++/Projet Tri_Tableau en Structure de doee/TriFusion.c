#include <stdio.h>
void Fusionner(int *tab,int p,int q,int r)
{
    int i = p;
    int j = q+1;
    int tmp[r-p+1];
    int k = 0;

    while(i<=q && j <= r)
    {
        if(tab[i] < tab[j])
        {
            tmp[k] = tab[i];
            i++;
        }else
        {
            tmp[k] = tab[j];
            j++;
        }
        k++;
    }
    while(i <= q)
    {
        tmp[k] = tab[i];
        i++;
        k++;
    }
    while(j <= r)
    {
        tmp[k] = tab[j];
        j++;
        k++;
    }
    for(k = 0;k < r-p+1;k++)
    {
        tab[p+k] = tmp[k];
    }
}

void TriFusion(int*tab,int p,int r)
{
    if(p<r){
        int q = (p+r)/2;
        TriFusion(tab,p,q);
        TriFusion(tab,q+1,r);
        Fusionner(tab,p,q,r);
    }
}
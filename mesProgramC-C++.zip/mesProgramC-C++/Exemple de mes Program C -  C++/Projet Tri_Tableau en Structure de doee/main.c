#include <stdio.h>
#include "TriBulle.c"
#include "TriFusion.c"
#include "TriInsertion.c"
#include "TriSelection.c"
#include "TriRapide.c"
#include "TriParTas.c"

void main()
{
  int i,n;
  int tri = 0;
  //Initialisation de la taille du tableau
  printf("Entrez la taille du tableau : ");
  scanf("%d",&n);
  int tab[n];
  printf("Entrez les elements du tableau \n");
  for(i = 0;i < n;i++)
  {
    printf("Entrez le %d elements : ",i);
    scanf("%d",&tab[i]);
  }

  typedef struct tableau tabs;
  tabs.tabl=tab;
  tabs.longeur=n;
  tabs.taille=n;  
  while(tri<1 || tri > 5)
  {
    printf("Comment voulez vous on trie se tableau\n");
    printf("Entrez 1 pour le tri Bulle\n");
    printf("Entrez 2 pour le tri Fusion\n");
    printf("Entrez 3 pour le tri Insertion\n");
    printf("Entrez 4 pour le tri Selection\n");
    printf("Entrez 5 pour le tri Rapide\n");
    printf("Entrez 6 pour le tri Tas\n");
    printf("choisi un tri : ");
    scanf("%d",&tri);
  }
  printf("*******Le tableau initiale*******\n");
  for(i = 0;i < n;i++)
  {
    printf("%d ",tab[i]);
  }
  switch(tri)
  {
    case 1:
    TriBulle(tab,n);
    break;
    case 2:
    TriFusion(tab,0,n-1);
    break;
    case 3:
    TriInsertion(tab,n);
    break;
    case 4:
    TriSelection(tab,n);
    break;
    case 5:
    TriRapid(tab,0,n-1);
    break;
    case 6:
    Triertas(tabs);
    break;
    
  }
  printf("\n*******Le tableau trie*******\n");
  for(i = 0;i < n;i++)
  {
    printf("%d ",tab[i]);
  }
}

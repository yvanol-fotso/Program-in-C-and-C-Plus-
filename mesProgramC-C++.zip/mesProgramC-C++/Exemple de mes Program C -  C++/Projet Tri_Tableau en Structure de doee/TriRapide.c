#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void permuter(int*a,int*b){
	
	int tmp;
	
	 tmp=*a;
	 *a=*b;
	 *b=tmp;
}

  void TriRapid(int tab[],int first, int last){
  	
  	int pivot,i,j;
  	
  	 if(first < last){
  	 	
  	 	pivot=first;
  	 	i=first;
  	 	j=last;
  	 	
	   
	   while(i < j){
	   	
	   	 while(tab[i] <= tab [pivot] && i< last)
	   	    i++;
	   	    
	   	    while(tab[j] > tab[pivot] && j>first)
	   	        j--;
	   	        
	   	        if(i <j ){
	   	        	
	   	        	permuter( &tab[i],&tab[j]);
	   	        	
				}
	   	
	   }
	   
	      permuter(&tab[pivot],&tab[j]);
  	
  	      TriRapid(tab,first,j-1);
  	
       	  TriRapid(tab,j+1,last);
  	
    }
    


  }

#include <stdio.h>
void TriInsertion(int *tab,int n){
    int i,j,tmp;
     for(i = 0; i<=n-1; i++){
        j = i;
         while(j > 0 && tab[j-1] > tab[j]){
            tmp = *(tab+j);
            *(tab+j) = *(tab+j-1);
            *(tab+j-1) = tmp;
            j = j-1;
         }
     }
} 
#include <stdio.h>
#include <stdlib.h>



typedef struct tableau {
    int* tabl;
    int taille;
    int longeur;
} tableau;

void construireTas(tableau tabl);
void entasser(tableau tabl, int i);
void echanger(int* a, int* b);
void trierTas(tableau tabl);
int gauche(int);
int droite(int);



void trierTas(tableau tabl){

    int i;
    construireTas(tabl);
    for( i=tabl.longeur-1; i>=1; i--){
        echanger(&tabl.tabl[0], &tabl.tabl[i]);
        tabl.taille--;
        entasser (tabl,0);
    }

}

void construireTas(tableau tabl){

    int i=0;
    tabl.taille = tabl.longeur;
    for(i= (tabl.longeur-1)/2; i>=0; i--){
        entasser (tabl,i);
    }

}

void entasser(tableau tabl,int i){

    int g= gauche(i);
    int d=droite(i);
    int max;
    max=i;
    if (g< tabl.taille && tabl.tabl[g]> tabl.tabl[max] ){
        max=g;
    }
    if (d< tabl.taille && tabl.tabl[d]> tabl.tabl[max] ){
        max=d;

    }
    if(max != i ){
        echanger(&tabl.tabl[i], &tabl.tabl[max]);
         entasser(tabl, max);
    }


}

void echanger(int* a, int* b){

    int c;
    c=*a;
    *a=*b;
    *b=c;
}

int gauche(int i){
  return(2*i);
}

int droite(int i){
    return(2*i+1);
}


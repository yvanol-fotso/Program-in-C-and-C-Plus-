#include <stdio.h>
#include <stdlib.h>

void Trfusion(int*tab,int debut, int fin){
	
	int mil=(fin-debut)/2 ;
	
	if( (fin-debut)<=0 )
	
	  return;
	  
	  Trifusion(tab,debut,mil);

      Trifusion(tab,mil+1,fin);	 
	  
	  fusionner(tab,debut,fin,mil); 

    return;
		
}



void fusionner(int*tab,int debut,int fin, int mil){
	
	int*t=(int*)malloc(sizeof(int)*(fin-debut+1));
		
		int i= debut, j=fin,k=0;
		
		 while(i=mil && j<=fin){
		 	
		 	
		 	if(tab[i]<tab[j])
		 	  
		 	  t[k++]=tab[i++];
		 	  
		 	  else
		 	  
		 	   t[k++]=tab[j++];
		 	
		 }
		 
		  while(i<=mil)
		  
		     t[k++]=tab[i++];
		     
		     while(j<=fin)
		     
		       t[k++]=tab[j++];
		       
		      for(i=0; i<k ;i++)
			  
			   tab[debut+i]=t[i];
			   
			  free(t);  
		
	
}


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	
	  int n,i, debut,fin ,mil;
	  
	   debut=0;
	   fin=n-1;
	  
	   mil=(fin-debut)/2;
	  
    
    int TAB [100];
    
   //  int *TAB=(int*)malloc(sizeof(int)*n);
    
    printf ("\n entrer la taillle de votre tableau:");
    
        scanf("%d",&n);

    printf("\n entre les elements du tableau ");

    for(i=0;i<n;i++){
    	
    	 scanf("%d",&TAB[i]);
	
   	    // printf("elements %d\n",i);	
   	     
    }
    
    printf("\n le tableau avant le tri est: ");
    
    for(i=0;i<n;i++){
    	
	    printf("%d  ",TAB[i]);
    }
    
	 printf("\n\n");
	
    Trifusion(TAB,debut,fin,mil);
    
     printf("\n le tableau apres le tri est: ");
    
    for(i=0;i<n;i++){
	
         printf("%d  ",TAB[i]);
         
    }
    
    printf("\n");
    
    return 0;
	
}

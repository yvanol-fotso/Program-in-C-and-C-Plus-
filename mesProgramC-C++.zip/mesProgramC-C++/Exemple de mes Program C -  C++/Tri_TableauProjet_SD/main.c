#include <stdio.h>
#include "TriBulle.c"
#include "TriFusion.c"
#include "TriInsertion.c"
#include "TriSelection.c"
#include "TriRapide.c"
#include "TriParTas.c"

void main()
{
  int i,n;
  int tri = 0;
  int k =1; //elle me permettra de demander a l'utilisateur s'il veut recommencer
  
  //Initialisation de la taille du tableau
  
  
  while(k==1){
  
  
  printf("Entrez la taille du tableau : ");
  scanf("%d",&n);
  int tab[n];
  printf("Entrez les elements du tableau \n");
  for(i = 0;i < n;i++)
  {
    printf("Entrez l'elements %d  : ",i);
    scanf("%d",&tab[i]);
  }
  
//declaration d'une structure

  struct tableau tabs;
  tabs.tabl=tab;
  tabs.longeur=n;
  tabs.taille=n;
  
    
  while(tri<1 || tri > 6)
  {
    printf("Comment voulez vous on trie se tableau\n");
    printf("Entrez 1 pour le tri Bulle\n");
    printf("Entrez 2 pour le tri Fusion\n");
    printf("Entrez 3 pour le tri Insertion\n");
    printf("Entrez 4 pour le tri Selection\n");
    printf("Entrez 5 pour le tri Rapide\n");
    printf("Entrez 6 pour le tri Tas\n");
    printf("choisi un tri : ");
    scanf("%d",&tri);
  }
  printf("*******Le tableau initiale*******\n");
  for(i = 0;i < n;i++)
  {
    printf("%d ",tab[i]);
  }
  switch(tri)
  {
    case 1:
    TriBulle(tab,n);
    break;
    case 2:
    TriFusion(tab,0,n-1);
    break;
    case 3:
    TriInsertion(tab,n);
    break;
    case 4:
    TriSelection(tab,n);
    break;
    case 5:
    TriRapid(tab,0,n-1);
    break;
    case 6:
    trierTas(tabs);
    break;
    
  }
  printf("\n*******Le tableau trie*******\n");
  for(i = 0;i < n;i++)
  {
    printf("%d ",tab[i]);
  }
  //cette partie est pour repeter le programme
  
  printf("\n");
  printf("voulez vous continuez? si oui entrez 1 sinon entrez 0 : ");
  scanf("%d",&k);
  tri=0;
  
  printf("\n"); //pour creer l'espace entre l'anciennne execution et le nouvelle
 
  }//je ferme le while k==1 cette boucle me permet de repeter le programme tantque le k==1 
  //ie le bouton frapper par le user au clavier et recuperer par la var k
// je pouvais aussi travailler avec tri pour faire la repetition
}



#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void permuter(int*a,int*b){
	
	int tmp;
	
	 tmp=*a;
	 *a=*b;
	 *b=tmp;
}

  void TriRapid(int tab[],int first, int last){
  	
  	int pivot,i,j;
  	
  	 if(first < last){
  	 	
  	 	pivot=first;
  	 	j=last;
  	 	
	   
	   while(i < j){
	   	
	   	 while(tab[i] <= tab [pivot] && i< last)
	   	    i++;
	   	    
	   	    while(tab[j] > tab[pivot])
	   	        j--;
	   	        
	   	        if(i <j ){
	   	        	
	   	        	permuter( &tab[i],&tab[j]);
	   	        	
				}
	   	
	   }
	   
	      permuter(&tab[pivot],&tab[j]);
  	
  	      TriRapid(tab,first,j-1);
  	
       	  TriRapid(tab,j+1,last);
  	
    }
    

  	return;
  }

int main() {
	
	int tab[100],nbr,i;
	
	printf("\n Entrer le nombre total d'elements :");
	scanf("%d",&nbr);
	
	printf("\n Entre les elements du tableau:");
	    
	     for(i=0;i<nbr;i++){
	     	
	     	scanf("%d",&tab[i]);
	      }
	         	
	     	
  TriRapid(tab,0,nbr-1);
  
  
  printf("\n le tableau trie est :");
  
   for(i=0;i<nbr;i++){
   	
   	  printf("%d  ",tab[i]);
   		
   }
   
   printf("\n");
   
	
	return 0;
}

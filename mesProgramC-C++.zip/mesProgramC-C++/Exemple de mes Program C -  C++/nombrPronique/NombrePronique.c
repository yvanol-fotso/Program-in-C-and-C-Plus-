        // EXO 
/*ecrire un algorithme qui verifie si un nombre naturel VAL est PRONIQUE et affiche le produit consecutifs
 qui donne VAL (rien a afficher si le nombre  est NOM PRONIQUE )
 un nombre pronique est le produits de deux entier  naturels consecutif (un nombre entier naturel compris entre 0 inclusivement et l'infini:0,1,2..)
 EXEMPLE : 272 , 12 ; car 272  = 16 * 17 ; 12 = 3*4  */       



#include <stdio.h>
#include <stdlib.h>


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

 main() {
 	
 	int N,i=1;
    int verif = 0;           //	bool  verif= false; 	// notons que la declaration avec les booeens ne marche pas en C en que par convention du language 0 signifie Vrai
 	                       //  exple :return 0 ie que le programm s'est bien executer et 1 pour sinoon donc 0 --> VRAI et 1--> FAUX  mais moi je ferai l'inverse ie 0=FAUX et 1= VRAI
 	
 	do{
 		printf("Donner un entier positif : ");
 		scanf("%d" , &N);
 		
	 }while(N<0);
	 
	 while((i<=N)||(verif = 0)){
	 	
	 	if(i*(i + 1)== N ){
	 		
	 		printf("\n Votre nombre es PRONIQUE");
	 		verif=1;   
	 		printf("\n %d  = %d * %d ", N , i , i + 1 );
	 	 }
	 	  
	 	 i++; 
	 }
        if((verif != 1) && (verif==0))   printf("\n Votre nombre n'est pas PRONIQUE");	// s'est bizzar sa ne fait pas totalement comme jae veux 
}


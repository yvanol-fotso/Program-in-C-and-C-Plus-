                  //ecrire une fonction 

//qui permet de verifier si un mot de longueur L est un PALINDROME ( est un mot qui se lit indifferemment de gauche a droite vice versa EXemple: RADAR
//esst un palindrome                  

#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int palindrome(char *mot)
{
	int k=0,i,n;
	n=strlen(mot);
	
	for(i=0 ;i< n/2 ;i++)
	{
		if(mot[i]==mot[n-i-1])
		k=k+1;
	}
	
	if((k==n/2)) return 1; else return 0;
}

 main() {
 	
 	char mot[50];
 	printf("donner un mot :");
 	scanf("%s" ,&mot); // RQ notons ici que on a pas besoin de mette & devant mot c'inutile car 'mot' est deja une adresse or l'adresse d'1 tableau
 	                 // est un pointeur sur le 1er elt du tab ou ...
 	if(palindrome(mot)==1)
 	 
 	   printf("votre mot est un palindrome");
 	   
 	 else printf("votre mot n'est pas un palindrome");  
}

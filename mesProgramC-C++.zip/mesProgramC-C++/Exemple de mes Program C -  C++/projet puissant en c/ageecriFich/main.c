#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	FILE *fich;
	int age;
	char nom[50];
	
	fich = fopen("essai.txt","w");
	
	if(fich != NULL)
	{
	// on demande l'age
	printf("QUEL EST VOTRE AGE ?");
	
		scanf("%d",&age);
		
		
		fprintf(fich, "le Mr qui utilise ce pc a %d ans" ,age);
		
    }
	return 0;
}

      //ENONCE DE L'EXO 

//ecrire un programme c qui copie le fichier Fichier1.txt dans le Fichier2.txt ceci enregistrement par enregistrement le fichier est de type
//enregistrement de 3 champs : NOM, PRENOM, MATRICULE (entier)      


#include <stdio.h>
#include <stdlib.h>
 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

main() {
	
	// F  variable qui pointera sur un fichier nomme Fichier1.txt et G : -//- sur Fichier2.txt
	
	FILE *F , *G ; char NOM[20] ,PRENOM[20]; int MATRICULE ; 
	
	F=fopen("Fichier1.txt" ,"r"); // ouverture de l'ancien fichier den lecture
	
	if(!F)
	{
	printf("erreur:impossible d'ouvrir le fichier1 \n");	
		exit(-1);	
	}
	G=fopen("Fichier2.txt" ,"w"); //ouverture du nouveau fichier en ecriture
	if(!G)
	{
	printf("erreur:impossible d'ouvrir le fichier2 \n");	
		exit(-1);			
	}
	   //Copie de tous les enregistrements
	   
	   while(!feof(F)) // ie tantque l'ouverture de F a reuissi et que il ne pointe pas sur EOF (end of file)
	   {
	   	
	   	fscanf(F,"%d \n %s \n %s \n" , &MATRICULE , NOM,PRENOM);
	   	fprintf(G,"%d \n %s \n %s \n" , MATRICULE , NOM,PRENOM );
	   	
	   }
	printf("..........COPIE TERMINER..........");
	
	fclose(F); fclose(G); // fermeture de F et G apres la copie
}

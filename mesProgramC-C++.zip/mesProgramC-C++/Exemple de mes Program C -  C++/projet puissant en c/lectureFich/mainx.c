#include <stdio.h>
#include <stdlib.h>


void Ouverture(){
	
	FILE  *F; // NB toujours ecrire FILE en majuscule complete
	char c,nomF[14];
	printf("donnez le nom du fichier :");
	gets(nomF);
	if((F = fopen(nomF,"r")) == NULL) // si l'oiverture a marche ie pointeur different de Null alors on peut lire et ecrire dans le fichier
	  printf("\nEREUR D OUVERTURE DU FICHIER : %s\n" ,nomF);
	else
	{
		
			printf("\n\t\t\tLISTING  DU FICHIER : %s\n" ,nomF); // au cas contraire on affiche un message d'erreur
			
			while((c=getc(F)) != EOF) printf("%c" ,c);
	
	}
	fclose(F);
	
    }
	
	
   main(){
		
		Ouverture();
		
	}
	

//exo : il sagit d'ecrire une action parametre en language c qui permet de lire un fichier,avec un controle d'erreur:l'utilisateur saisit
//le nom et l'extension du fichier,l'ordinateur affiche le contenue du fichier s'il existe et un message d'erreur si pas 

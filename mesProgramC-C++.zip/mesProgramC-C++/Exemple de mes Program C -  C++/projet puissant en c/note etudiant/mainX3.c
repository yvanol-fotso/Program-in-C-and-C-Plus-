                 // enonce de l'exo

//ecrire un programe c qui define les enregidtrement etudiant(unetudiant es representer par sont nom, sa note),lit en suite
//une liste d'etudiant entree pa l'utilisateur et affiche les noms de tous les etudiants ayants une note superieur ou egale a 10/20                 


#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct Etudiant{

    char nom[20], prenom[30];
    float note;
} *Etudiant;  // RQ si j'omet ( ne met pas *Etudiant) sa generera une erreur au niveau de la ligne main()s 

 main() {
	
	struct Etudiant t[50];
	int n,i;
	
	printf("donner le nombre d'etudiants \n");
	scanf("%d" , &n);
	
	for(i=1; i<=n ;i++)
	{
		printf("donner le nom, prenom et la note de l'etudiant %d : \n" ,i);
		scanf("%s \n %s \n %f" ,t[i].nom, t[i].prenom, &t[i].note);
	}
	
	printf("les etudiants ayants une note superieures a 10/20 ou moyenne sont : \n");
	for(i=1 ; i<=n ;i++)
	{
	if(t[i].note >= 10)
	printf("%s \n %s \n" ,t[i].nom , t[i].prenom);	
		
	}
	
}

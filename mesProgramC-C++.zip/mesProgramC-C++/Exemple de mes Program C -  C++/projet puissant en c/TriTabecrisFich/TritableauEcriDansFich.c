     // ENONCE 
//ecrire un programme qui lit 10 valeurs entieres d'un fichier de 10 entiers ,les place dans un tableau, tri le tableau dans l'ordre croisant et place
//ce tableau trie dans le meme fichier a la place ds 10 valeurs de depart


#include <stdio.h>
#include <stdlib.h>


FILE *F;

void CREATION(){
	
	int i,x;
	
	F=fopen("fichier.txt","w");
	
	 for(i=1 ;i<=10; i++){
	 	printf("donez  la valeur %d :",i);
	 	scanf("%d" ,&x);
	 	
	 	fprintf(F, "%d \n" ,x);
	 }
	 fclose(F);
}
	
void TRIEFICHIER(){
	
	int i=1 ,j ,x ,tmp ,t[10];
	
	F=fopen("fichier.txt" , "r");
	
	while(!eof(F)){
		
		fscanf(F, "%d \n" , &x);
		t[i]=x;
		i++;
	}
	fclose(F);
	
	// tri par selection du tableau
	
	for(i=1; i<=9 ;i++)
	  for(j=i+1 ;j<=10 ;j++)
	    if(t[i] > t[j]){
	    	
	    	tmp=t[i];
	    	t[i]=t[j];
	    	t[j]=tmp;
	    
		}
	
	F=fopen("fichier.txt" , "w");
	for(i=0 ;i<=10;i++){
		fprintf(F ,"%d \n" , t[i]);
	}
	fclose(F);
    }
    
void AFFICHERFICH(){
	
	int x;
	F=fopen("fichier.txt" , "r");
	
	while(!eof(F)){
		
		fscanf(F, "%d \n " , &x);
		printf(" %d" , x);
	}
	fclose(F);
}     

main(){
	
  CREATION();
  printf("\n Fichier avant le trie : \n");
  AFFICHERFICH();
  TRIEFICHIER();
  printf(" \n Fichier apres le trie : \n");
  AFFICHERFICH();	
	
}

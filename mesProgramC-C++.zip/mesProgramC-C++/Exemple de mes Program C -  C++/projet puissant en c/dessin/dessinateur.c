#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int i,j,n;
	
	printf("donner un entier : ");
	scanf("%d",&n);
	printf("\n");
	
	for(i=0;i<n;i++){
		
		for(j=1;j<=(n*2)-1;j++){
			
			if(j>=n-1 && j<=n+1)
			
			  printf("*");
			  
			  else printf(" ");
			  
		}
		printf("\n");
		
     	}
     	getch();
	
//	return 0;
}

                //ENONCE DE LEXO MI PREMIERE ANNE SEMESTRE2.MATIER ALGO ET STRUCTURE DE DONNE 2
                
//on veut gerer un groupe d'etudiant en utilisant les un fichier<<etudiant>> dont les informations sont structurees selon la maniere suivante:
// ->NUMERO DE MATRICULE(entier)
// ->NOM(chaine de caracteres)
// ->PRENOM (chaine de caractere)
// ->MOYENNE(reel)
//en utilisant les actions parametrees,ecrire un algorithme qui permet de:
//  1 -creer le fichier <<etudiant.txt>> le nombre d'etudiant est a fournir par l'utilisateur
// 2-afficher les informations de l'etudiants  ainsi que la moyenne des notes du groupes
// 3-ajouter un nouvel etudiant au groupe
// 4-inserer un nouvel enregistrement dans <<etudiant>> en supposant que le fichier est trie relativement au champ ** NOM**
// 5-Supprimer dans <<etudiant.txt>>tous les etudiants dont la moyenne est inferieure a 10            



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define maxList 50
#define PARMAT 1
#define PARNOM 2
#define PARPRNOM 3
#define PARMOY 4


//types

typedef struct {
	
	int numMat;
	
	char nom[20];
	
	char prenom[20];
	
	float moy;

} tEtudiant;

//prototypes

int creatFichEtud(char nomFichier[]),

affichFichEtud(char nomFichier[]),

inserInFich(tEtudiant etud, char nomFichier[]),

triFichEtud(char nomFich[] ,int clef),

inserInFichTrie(tEtudiant etudInser , char nomFichier[] ,int clef),

supprEtudAjrn(char nomFichier[]);

float getMoyGr(char nomFichier[]);

tEtudiant getInfoEtud();

bool compareEtud(tEtudiant etud1 ,tEtudiant etud2 ,int clef);

//variables

int nbrEtud;

char nomFichier[30] = "etudiant.txt";

FILE *ptFichier ;  // global pour deboguer, ensuite a enlever

tEtudiant etud;


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int clef  = PARNOM; //cle de tri
	
	creatFichEtud("etudiant.txt");
	
	printf("\n Fichier d'origine :");
	
	affichFichEtud("etudiant.txt");
	
	printf("\n Moyenne du groupe : %2f" ,getMoyGr("etudiant.txt"));
	
	printf("\n Donner les info de l'etudiant a inserer :");
	
	etud = getInfoEtud();
	
	inserInFich(etud ,"etudiant.txt");
	
	printf("\n Fichier apres insertion de %s :" , etud.nom);
	
	affichFichEtud("etudiant.txt");
	
	// triFichEtud("etudiant.txt" , clef); //a definir vous meme
	
	printf("\n Fichier trie par (1-Mat   2-Nom  3-Prenom  4-Moy) :%d" ,clef);
	
	affichFichEtud("etudiant.txt");
	
	printf("\n Donner les info de l'etudiant a inserer dans le Fich trie :'");
	
	etud = getInfoEtud(etud);
	
	inserInFichTrie(etud , "etudiant.txt" , clef);
	
	printf("\n Fichier apres insertion :");
	
	affichFichEtud("etudiant.txt");
	
	supprEtudAjrn("etudiant.txt");
	
	printf("\n Apres suppression des ajournes, le groupe devient :");
	
	affichFichEtud("etudiant.txt");
	
	return 0;
}

int supprEtudAjrn(char nomFichier[]){
	
	tEtudiant etud;
	
	FILE *tmpFich , *ptFichier ;
	
	tmpFich = fopen("tmpFich.txt" , "w");
	
	if(! tmpFich){
		
		printf("\n Une erreur est survenue lors de l'ouverture du fichier"); return 1 ;
	}
	ptFichier = fopen(nomFichier ,"r");
	
	if(! ptFichier){
		
		printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
		
		return 1;
	}
	
	/*pour supprimer des enregistrements dans un fichier, un nouveau fichier est cree(tmpFich) en copiant tous les enregistrements de l'ancien 
	fichier sauf les enregistrements a supprimes */
	
	while(fscanf(ptFichier , "%d \t %s \t %s\t %f \n" , &etud.numMat , etud.nom , etud.prenom , &etud.moy )==4){
		
		if(etud.moy >=10){
			
			/*on insert les enregistrements donts les notes sont >= 10 dans le fichier ** tmpFich **  */
			
			fprintf(tmpFich , "%d \t %s \t %s\t %2f \n" , etud.numMat , etud.nom , etud.prenom , etud.moy); 
	    }
	}
	fclose(tmpFich);
	fclose(ptFichier);
	
	remove(nomFichier); //on efface l'ancien fichier
	
	rename("tmpFichier.txt" , nomFichier); // on renomme les nouveau 
	
	/*MEthode 2 : on peut aussi copier tous les enregistrements du fichier temporaire vers etudiants.txt */
	
	return  0;
	
}


int inserInFichTrie(tEtudiant etudInser , char nomFichier[] ,int clef ){
	
	tEtudiant etud;
	
		FILE *tmpFich , *ptFichier ;
		
		bool inser;
	
	tmpFich = fopen("tmpFich.txt" , "w");
	
	if(! tmpFich){
		
		printf("\n Une erreur est survenue lors de l'ouverture du fichier"); return 1 ;
	 }
	ptFichier = fopen(nomFichier ,"r");
	
	if(! ptFichier){
		
		printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
		
		return 1;
	}
	
     inser = false;
	
	while(fscanf(ptFichier , "%d \t %s \t %s\t %f \n" , &etud.numMat , etud.nom , etud.prenom , &etud.moy )==4){
		
		if( compareEtud(etud , etudInser ,clef)){
			
			
			fprintf(tmpFich , "%d \t %s \t %s\t %2f \n" , etud.numMat , etud.nom , etud.prenom , etud.moy);
			 
	    }else{
	    	
	    	fprintf(tmpFich , "%d \t %s \t %s\t %2f \n" , etudInser.numMat , etudInser.nom , etudInser.prenom , etudInser.moy);
	    	
	    	fprintf(tmpFich , "%d \t %s \t %s\t %2f \n" , etud.numMat , etud.nom , etud.prenom , etud.moy);
	    	
	    	inser = true;
	    	
	    	strcpy(etudInser.nom ,"ZZZ");
	    	
		}
	}
	if(! inser){
		
			fprintf(tmpFich , "%d \t %s \t %s\t %2f \n" , etudInser.numMat , etudInser.nom , etudInser.prenom , etudInser.moy);
	}
	
	fclose(tmpFich);
	fclose(ptFichier);
	
	remove(nomFichier);
	
	rename("tmpFich.txt" , nomFichier);
	
	return 0;
	
}

int inserInFich(tEtudiant etud , char nomFichier[]){
	
	ptFichier =fopen(nomFichier ,"a");
	
	if(! ptFichier){
	   
	   printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
	   
	   return 1;	
	}
	 fprintf(ptFichier , "%d \t %s \t %s \t %2f \n" , etud.numMat , etud.nom , etud.prenom , etud.moy);
	 
	 fclose(ptFichier);
	 
	 return 0;
	 
}

// en plus pour generaliser 

bool compareEtud(tEtudiant etud1, tEtudiant etud2 , int clef){
	
	switch(clef){
		
		case PARNOM : return (strcmp(etud1.nom ,etud2.nom) < 0);
		
		case PARPRNOM :return (strcmp(etud1.prenom , etud2.prenom) < 0);
		
		case PARMAT : return(etud1.numMat  < etud2.numMat);
		
		default :return (etud1.moy > etud2.moy );
	}
	
}

float getMoyGr( char nomFichier[]){
	
	tEtudiant etud;
	
	int nbrEtud;
	
	float moy;
	
	ptFichier = fopen(nomFichier ,"r");
	
	if(! ptFichier){
		
	   printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
	   
	   return 0;	
		
	}
	moy = 0; nbrEtud = 0;
	
	while(fscanf(ptFichier ,"%d \t %s \t %s\t %f \n" , &etud.numMat , etud.nom , etud.prenom , &etud.moy )==4 ){
		
		moy +=etud.moy; // notons que on ne met pas l'espace entre + et = 
		
		nbrEtud ++ ;
	}
	if(nbrEtud) moy /=nbrEtud ;
	
	return (moy);
	
}
	
	
tEtudiant getInfoEtud(){
	
	tEtudiant etud;
	
	printf("\n donner le matricule de l'etudiant (entier) : ");
	
	scanf("%d" , &etud.numMat);
	
	printf("\n donner le nom (sans espace) de l'etudiant :");
	
	scanf("%s" ,etud.nom); // on n'utilise pas le & (e commerciale sur les chaine de caractere)
	
    printf("\n donner le prenom (sans espace) de %s :" , etud.nom);
		
    scanf("%s" ,etud.prenom); // on n'utilise pas le & (e commerciale sur les chaine de caractere)
	
	printf("\n donner la moyenne de %s  %s  : " ,etud.nom , etud.prenom);
	
	scanf("%f" , &etud.moy);
	
	return (etud);			
		
}	

int affichFichEtud(char nomFichier[]){
	
	tEtudiant etud;
	
	ptFichier = fopen(nomFichier , "r");
	
	
	if(! ptFichier){
	   
	   printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
	   
	   return 1;	
	}
	printf("\n ----------------------------------------------------------------------");
	
	printf("\n MATRICULE   \t NOM   \t PRENOM   \t MOy");

	while(fscanf(ptFichier ,"%d\t   %s\t   %s\t   %f\n" , &etud.numMat , etud.nom , etud.prenom , &etud.moy )==4 ){
		
	
	printf( "\n %10d \t %-10s \t %-10s\t %05.2f " , etud.numMat , etud.nom , etud.prenom , etud.moy);	
	
   }
    printf("\n ----------------------------------------------------------------------");

    fclose(ptFichier);

    return 0;

}

int creatFichEtud(char nomFichier[]){
	
	tEtudiant etud;
	
	int i;
	
	ptFichier = fopen(nomFichier ,"w");
	
	if(!ptFichier){
		
	  printf("\n L' ouverture du fichier %s a echouee! " , nomFichier);
	   
	   return 1;		
	}
	
	printf("donner le nombre d'etudiant du groupe :");
	
	scanf("%d" , &nbrEtud);
	
	for(i=0 ; i<= nbrEtud ; i++){
		
		etud= getInfoEtud();
		
	    fprintf(ptFichier , "%d \t %s \t %s\t %2f \n" , etud.numMat , etud.nom , etud.prenom , etud.moy);
		
	} 
	fclose(ptFichier);
	
	return 0;
	
}

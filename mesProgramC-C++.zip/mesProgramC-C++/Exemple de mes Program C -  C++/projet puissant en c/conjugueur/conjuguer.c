#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LONGMAX 26

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

//on efface le int qui est devant main et les argument

main() {
	
	char verbe[LONGMAX + 1];
	char * adfin ;
	char * terminaison[6]={"e", "es", "e", "ons", "ez", "ent"};
	char * debut[6]={"je", "tu", "il", "nous", "vous", "IlsouElles"};
	int i;
	do
	{
		printf("donnez un verbe du premier groupe : ");
		
		gets(verbe);
		
		adfin=verbe + strlen(verbe)-2 ;
	}
	while(strcmp (adfin,"er")) ;
 
    printf("\nIsndicatif present :\n");
	
	 for(i=0;i<6;i++){
	 	strcpy (adfin,terminaison[i]);
	 	printf("%s %s\n",debut[i],verbe);
	 	
	 }	
	 // on enlever return   ou bien tout simplement 0 car 0 est un entier
	 
	return ;
}

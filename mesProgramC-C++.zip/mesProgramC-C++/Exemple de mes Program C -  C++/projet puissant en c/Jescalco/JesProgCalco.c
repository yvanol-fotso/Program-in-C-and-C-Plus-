//               PROJET CREATION D'UNE CALCULATRICE  appele **JesProg-Calculatrice**

/*RELISATION D'UNE CALCULATRICE COMPLETE EN C 1- nous realiserons un menu sur mesure pour permettre a l'utilisateur d'acceder directement aux different
fonctionnalites de notre calco  ;2- pour ce tp ,vous aurez besoin de creer un menu bien propre il faudra effacer l'ecran a chaque fois  l'orsque 
l'utilisateur choisi une fonctionnalite precise ;pour cele ,vous allez utiliser  ceci:  system("cls"); pour effacer l'ecran  */


#include <stdio.h>
#include <stdlib.h>


float additionneur(float nbr1, float nbr2){
	
	return nbr1+nbr2;
}


float soustracteur(float nbr1, float nbr2){
	
	return nbr1-nbr2;
}


float multiplieur(float nbr1, float nbr2){
	
	return nbr1*nbr2;
}

float diviseur(float nbr1, float nbr2){
	
	return nbr1/nbr2;
}



/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int choixMenu , revenir;
	double nombre_1 , nombre_2;
	
	do{
		
		printf("\n++++++++*JesProg-Calculatrice*+++++++++\n\n");
		printf("\t 1-ADDITION \n");
		printf("\t 2-SOUSTRACTION \n");
		printf("\t 3-DIVISION \n");
		printf("\t 4-MULTIPLICATION \n");
		printf("\t 5-SORTIR \n");
		printf("\n\tFAITES UN CHOIX :");
		
		scanf("%d" , &choixMenu);
		
		system("cls"); // cette fonction permet d'efface l'ecran		
		printf("\n");
		
		switch(choixMenu)
		{
			case 1 :
				printf("*********ADDITION********\n\n"); // TITRE DE L'OPTION CHOISIT
				printf("veuillez entrer les valeurs : \n\n\t");
				scanf("%1f" , &nombre_1);
				printf("\t+\n\t");
				scanf("%1f" , &nombre_2);
				printf("\t= %f\n\n" , additionneur(nombre_1, nombre_2));
				break;
				
			case 2 :
				printf("*********SOUSTRACTION********\n\n"); // TITRE DE L'OPTION CHOISIT
			   	printf("veuillez entrer les valeurs : \n\n\t");
				scanf("%1f" , &nombre_1);
				printf("\t-\n\t");
				scanf("%1f" , &nombre_2);
				printf("\t= %f\n\n" , soustracteur(nombre_1, nombre_2));
				break;	
				
			case 3 :
				printf("*********DIVISION********\n\n"); // TITRE DE L'OPTION CHOISIT
			   	printf("veuillez entrer les valeurs : \n\n\t");
				scanf("%1f" , &nombre_1);
				printf("\t/\n\t");
				scanf("%1f" , &nombre_2);
				printf("\t= %f\n\n" , diviseur(nombre_1, nombre_2));
				break;		
			 
			 case 4 :
			 	printf("*********MULTIPLICATION********\n\n"); // TITRE DE L'OPTION CHOISIT
			   	printf("veuillez entrer les valeurs : \n\n\t");
				scanf("%1f" , &nombre_1);
				printf("\t*\n\t");
				scanf("%1f" , &nombre_2);
				printf("\t= %f\n\n" , multiplieur(nombre_1, nombre_2));
				break;	   	
			
			case 5 :
				// return O;
				break;
				
			default :
			   printf("vous n'avez pas entrer un nombre correct. je me demande a quoi vous jouez :-(!");
			   break;	
			
		}
		
		printf("\n\n");
		
		printf("VOULEZ VOUS REVENIR AU MENU PRINCIPALE ? \n\n");
		printf("1-pour OUI \n\n2-pour SORTIR \n\n");
		scanf("%d" , &revenir);
		system("cls"); // permet d'effacer l'ecran
		
	}while(revenir==1);	
		
		return 0;
  }

#include <stdio.h>
#include <stdlib.h>


//PROGRAMME QUI VERIFIE SI UN NOMBRE ENTIER EST UN NOMBRE PREMIER

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int nb,i,r=0;
	
	printf("enntree un nombre:");
	 scanf("%d",&nb);
	 
	  for(i=1; i<=nb; i++){
	  	
	  	if(nb%i == 0)
	  	  
	  	  r++;
	  	  
	  }
	   if(r > 2)
	     printf("votre nombre n'est pas premier");
	     
	     else 
	       printf(" votre nombre est premier");
	       
	
	return 0;
}

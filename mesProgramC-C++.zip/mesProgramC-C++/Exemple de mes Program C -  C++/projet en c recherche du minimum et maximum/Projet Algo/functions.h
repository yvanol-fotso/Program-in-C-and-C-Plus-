void rechercheMaxMin(int tab[], int n, int *min, int *max){
    int i, valMin, valMax;

    valMin = tab[0];
    valMax = tab[0];

    for(i = 0; i < n; i++){
        if(tab[i] < valMin){
            valMin = tab[i];
        }
        if(tab[i] > valMax){
            valMax = tab[i];
        }
    }

    *min = valMin;
    *max = valMax;
}

/*  

    COMPLEXITE :
 
    Complexite en nombre de comparaisons : On a effectue exactement 2n - 2 comparaisons pour ateindre l'objectif
    Car nous avons deux boucles for dans notre algorithme.  

*/



/*

    Proposition d'un algorithme plus efficace.

    Methode a utiliser :
        - On compare les elements par paire
        - On met de cote les plus grands et de l'autre les plus petits
        - On reecherche le maximum parmis les plus grnds et le minimum parmis les plus petits
        - On n'oublie pas que ne n-ieme element n'a pas ete compare avec les autres, donc a la fin, on s'en occupe.
    Fin methode.

*/


void maxMin(int tab[], int n, int *min, int *max){
    
    int i, j, valMin, valMax;

    for(i = 0; i < n; i=i+2){
        if(tab[i] > tab[i+1]){
            int tmp = tab[i];
            tab[i] = tab[i+1];
            tab[i+1] = tmp;
        } 
    }

    valMin = tab[0];
    
    for(i = 2; i < n; i=i+2){
        if(tab[i] < valMin){
            valMin = tab[i];
        }
    }
    
    valMax = tab[1];
    
    for(i = 3; i < n; i=i+2){
        if(tab[i] > valMax){
            valMax = tab[i];
        }
    } 

    if(n%2 != 0){
        if(tab[n-1] > valMax){
            valMax = tab[n-1];
        }
    } 

    *max = valMax;
    *min = valMin;
}


/*

    QUESTION 4.

    COMPLEXITE :

    - Notre tableau principal se divise en deux : une pour les plus grands et l'autre pour les petits.
    - Lors de la segmentation en sous tableau, on effectue n/2 comparaison
    - On effectue donc pour chaque sous tableau (n/2 - 1) comparaisons 

    On a donc au final n/2 + 2(n/2 + 1) comparaison = n + n/2 - 2 comparaisons


    QUESTION 5 
        a-) Pour etre sur que notre algorithme de recherche du maximum et du minimum fonctionne correctement, 
            on doit effectuer n-1 comparaison pour le minimum (resp le maximum)
            Pou donc savoir que c'est bien le maximum (resp le minimum), il faut que les autres n-1 elements ne soient pas le minimum
            (resp le maximum).
            On aura donc a la fin 2n-2 unites d'informations.
        Fin de la question a.)

        b-) 

*/
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main(){
    int taille =  7;
    int tab[] = {10, 9, 14, -1, 0, -6, 20};
    int min, max;

    maxMin(tab, taille, &min, &max);

    printf("Le max est : %d, le min est %d \n", max, min);

    return 0;
}
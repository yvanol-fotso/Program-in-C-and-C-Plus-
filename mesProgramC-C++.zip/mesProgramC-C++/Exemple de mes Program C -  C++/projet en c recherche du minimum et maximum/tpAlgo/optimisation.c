#include <stdio.h>

void minMax(int *tab, int n);
int main(int arg, char argv){
    int tab[] = {0,8,6,10,11,12};
    minMax(tab,6);
    return 0;
}

void minMax(int *tab, int n){
    int max,min;
    max=tab[0];
    min=tab[0];
    for ( int i = 0; i < n; i=i+2)
    {
        
        if(max < tab[i]){
            max = tab[i];
            if(max < tab[i+1] && (i+1<n)){
                max = tab[i+1];
            }
        }

        if(min > tab[i]){
            min = tab[i];
            if(min > tab[i+1] && (i+1<n)){
                min = tab[i+1];
            }
        }
    }

    printf("le maximum est %d et le minimum %d\n", max, min);
    
}

/* la complexité de cette algoritme est O(n) ce qui n'est pas différent de l'autre*/

/* Question 5.a) l'algoritme doit produire n-1 recherche avant de trouver le resultat donc n-1 unités d'informations*/
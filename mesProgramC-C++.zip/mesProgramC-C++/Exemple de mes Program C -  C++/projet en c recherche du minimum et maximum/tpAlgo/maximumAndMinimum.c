#include <stdio.h>

void minMax(int *tab, int n);

int main(int arg, char argv)
{
    int tab[] = {5, 4, 9, 8, 2, 1};
    for (int i = 0; i < 6; i++)
    {
        printf("%d", tab[i]);
    }

    minMax(tab, 6);
    return 0;
}

void minMax(int *tab, int n)
{
    int max,min;
    max = tab[0];
    min = tab[0];
    int i;
    for (i = 0; i < n; i++)
    {
        if (max < tab[i + 1])
        {
            max = tab[i + 1];
        }
        if (min > tab[i + 1])
        {
            min = tab[i + 1];
        }
    }

    printf("\nle maximum est %d et le minimum est %d\n", max,min);
}



/* la complexite de cet algorithme pour la maimum comme le minimum est O(n) 
car le nombre d'opérations est  2n+2 */

#include <stdio.h>
#include <stdlib.h>

// j'ajoute la bibliotheque string.h et la constante preprocesseur #define...

#include <string.h>
#define W(_s)(word_t){.s=_s, .len=strlen(_s)}

     // EXO 
/* cette question est une question que l'on avais soumis a un personne lors d'un test d'essaie 
elle concerne  la definition des macros ,dico */

typedef struct word_t{
	
	const char*s;
	int len;
	
}word_t;     

int main() {
	
	word_t dico[]={W("yvapro"),W("...")};
	
	printf("chaine1 : %s\nLongueur :%d",dico[0].s,dico[0].len);
	
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	

	int tab[10000],temps;
	
    int time=0 ;
	
	   	//mon code 
	
	int nbdediv=0 , r=0 ,i ;
	int nombre=1;
	int taille,compteur=0;
	
	printf("\n Entrer le nombre des n-entier premier que vous voulez afficher:");
	  
	  scanf("%d",&taille);
	  
	    printf("\n\n");
	  
	  
	  while (nombre<=taille){
	  	
	  	nbdediv=0; //pour compter le nombre de diviseur
	  	
	  	nombre++;
	  
        	for(i=1; i<=nombre; i++){
		
	        	if((nombre%i)==0)
	      	
	      	     nbdediv++;
	     	}
		
		         	
		          if(nbdediv==2) //ie le nombre se divise par 1 et par lui meme 
		
		        {
		        	
		          printf("%d ",nombre);	
		        	
		        	
				}
					
							
      	} 
		  
	
		  
	time=clock();
	
	 printf("\n\n");
	
	 printf("\n Le Temps d'execution de tout le program est=%d ms",time);
	
	 printf("\n\n");
	
	return 0;  //ou return EXIT_SUCCESS;
}

#include <stdio.h>
#include <stdlib.h>

//int permuter(int*a,int*b){
	
//	int tmp;
	
//	tmp=*a;
//	*a=*b;
//	*b=tmp;
	
 // return 1;	
//}


void TriBulles(int tab[],int n){
	
	int permut=1, j,  i=n-1;

  while(permut && i>0){
  	
  		permut=0;
  		
  	for(j=0;j<i;j++){
  	
  		if(tab[j] > tab[j+1]){
  			
  			//permuter(&ta[j] , &tab[j+1]);
  			
  			int tmp =tab[j];
  		   	tab[j]=tab[j+1];
  		    tab[j+1]=tmp;
  			

  			permut =1;	
  			
		  }
  			
  		
	  }
	  
  	 i--;
  	
   }
  	return ;
  }

int main()
{
    int n,i ;
    
    int TAB [100];
    
   //  int *TAB=(int*)malloc(sizeof(int)*n);
    
    printf ("\n entrer la taillle de votre tableau:");
    
        scanf("%d",&n);

    printf("\n entre les elements du tableau ");

    for(i=0;i<n;i++){
    	
    	 scanf("%d",&TAB[i]);
	
   	    // printf("elements %d\n",i);	
   	     
    }
    
    printf("\n le tableau avant le tri est: ");
    
    for(i=0;i<n;i++){
    	
	    printf("%d  ",TAB[i]);
    }
    
	 printf("\n\n");
	
    TriBulles(TAB,n);
    
     printf("\n le tableau apres le tri est: ");
    
    for(i=0;i<n;i++){
	
         printf("%d  ",TAB[i]);
         
    }
    
    printf("\n");
    
    return 0;

}


#include<stdio.h>
#include<stdlib.h>
typedef struct 
{
	char date[20];
	int positif;
	int negatif;
}covid;
typedef struct{
	int totinfecte;
	int totnegatif;
	char date[20];
}totcovid;
int initialisation(int a)
{
	FILE *fichier;
	covid p;
	fichier=fopen("covid.txt","w");
	printf("entrez la date :\a");
	scanf("%s",&p.date);
	printf("nombre de cas positif\n");
	scanf("%d",&p.positif);
	printf("cas negatif:\a ");
	scanf("%d",&p.negatif);
	fprintf(fichier,"%s\n",p.date);
	fprintf(fichier,"%d\n",p.positif);
    fprintf(fichier,"%d\n",p.negatif);
    fclose(fichier);
    return a;
}
int ajouter_cas(int a )
{
	FILE *fichier;
	covid p;
	fichier=fopen("covid.txt","a");
	printf("entrez la date :\a");
	scanf("%s",&p.date);
	printf("nombre de cas positif\n");
	scanf("%d",&p.positif);
	printf("cas negatif:\a ");
	scanf("%d",&p.negatif);
	fprintf(fichier,"%s\n",p.date);
	fprintf(fichier,"%d\n",p.positif);
    fprintf(fichier,"%d\n",p.negatif);
    fclose(fichier);
}
int afficher_totaux(int a)
{
	totcovid p;
	FILE *fichier,*fich;
	covid x;
	printf("date----------total positif-------------total negatif\n");
	fichier=fopen("covid.txt","r");
	fich=fopen("totcovid.txt","w");
	p.totinfecte=0;
	p.totnegatif=0;
	while(!feof(fichier)){
		fscanf(fichier,"%s\n",&p.date);
		fprintf(fich,"%s\n",p.date);
		printf("%s      \a",p.date);
		fscanf(fichier,"%d\n",&x.positif);
		p.totinfecte=p.totinfecte+x.positif;
		fprintf(fich,"%d\n",p.totinfecte);
		printf("       %d   ",p.totinfecte);
		fscanf(fichier,"%d\n",&x.negatif);
		p.totnegatif=p.totnegatif+x.negatif;
		fprintf(fichier,"%d\n",p.totinfecte);
		printf("           %d     \n",p.totnegatif);	
	}fclose(fich);
	fclose(fichier);
}
int afficher_evolution(int a)
{
FILE *fichier;
covid p;
printf("date-----------total positif-------total negatif\n");
fichier=fopen("covid.txt","r");
while(!feof(fichier)){
	fscanf(fichier,"%s",&p.date);
	printf("%s           \a",p.date);
	fscanf(fichier,"%d\n",&p.positif);
	printf("    %d   ",p.positif);
	fscanf(fichier,"%d\n",&p.negatif);
	printf("        %d     \n",p.negatif);	
}fclose(fichier);}
int menu(int a)
{
	int x;
	printf("1: enregistrer les cas\n");
	printf("2: consulter l'evolution des cas\n");
	printf("3: ajouter des cas\n");
	printf("4: consulter les totaux\n");
	printf("0: quitter\n");
	printf("votre choix svp ");
	scanf("%d",&x);
	switch(x){
		case 1: x=initialisation(x);break;
		case 2: x=afficher_evolution(x);break;
		case 3: x=ajouter_cas(x);break;
		case 4: x=afficher_totaux(x);break;
		default: printf("choix indisponible");break;
	}
	return x;
}
int main()
{
	int x,a;
	x=menu(a);
	while(x!=0)
	{
		x=menu(a);
	}
}
